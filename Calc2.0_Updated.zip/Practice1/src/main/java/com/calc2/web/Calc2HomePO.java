package com.calc2.web;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Utilities.BasePageObject;
import junit.framework.Assert;

public class Calc2HomePO extends BasePageObject{
	
	Calc2HomePO po;
	public Calc2HomePO() {
		super();
	}
	
	public Calc2HomePO(String browser) {
		super(browser);
	}

	public enum FIELDS {

		InputBox(By.id("input")),
		BtnPlus(By.id("BtnPlus")),
		BtnCalc(By.id("BtnCalc")),
		BtnClear(By.id("BtnClear")),
		BtnMinus(By.id("BtnMinus")),
		BtnParanR(By.id("BtnParanR")),
		BtnMult(By.id("BtnMult")),
		BtnSin(By.id("BtnSin")),
		BtnParanL(By.id("BtnParanL")),
		BtnHistory(By.xpath("//div[@id='hist']/button[contains(@class,'dropdown-toggle')]")),
		HistoryList(By.xpath("//div[@id='histframe']/ul/li"));
		private By findby;

		FIELDS(By findby) {
			this.findby = findby;
		}
	}
	
	public void clickbasicCalculatorButton(String btn) {
		clickElementSafely(By.xpath("//button[@id='Btn"+btn+"']"),240);
	}
	public void clickOnPlus() {
		clickElementSafely(FIELDS.BtnPlus.findby);
	}
	public void clickOnMinu() {
		clickElementSafely(FIELDS.BtnMinus.findby);
	}
	public void clickEquals() {
		clickElementSafely(FIELDS.BtnCalc.findby);
	}
	public String getResult() {
	return	getElementSafely(FIELDS.InputBox.findby).getAttribute("value");	
	}
	
	public void clickOnClear(){
		clickElementSafely(FIELDS.BtnClear.findby);
	}
	
	public void clickOnRightParenthesis(){
		clickElementSafely(FIELDS.BtnParanR.findby);
	}
	public void clickOnLeftParenthesis(){
		clickElementSafely(FIELDS.BtnParanL.findby);
	}
	public void clickOnBtnMult(){
		clickElementSafely(FIELDS.BtnMult.findby);
	}
	public void clickOnBtnSin(){
		clickElementSafely(FIELDS.BtnSin.findby);
	}
	
	public void verifyHistory(List<String> str) {
		
		
		clickElementSafely(FIELDS.BtnHistory.findby);
		int i=str.size()-1;
		for(WebElement el: getDriver().findElements(FIELDS.HistoryList.findby)) {
			String lt = el.findElement(By.xpath(".//p[@class='l']")).getText();
			String rt = el.findElement(By.xpath(".//p[@class='r']")).getText();
			//System.out.println(str.get(i)+"--->"+lt+" "+rt);
			Assert.assertEquals(str.get(i),lt+" "+rt);
			i--;
		}
	}
	
	public void enterInput(String value) {
		WebElement el = getElementSafely(FIELDS.InputBox.findby);
		JavascriptExecutor e = (JavascriptExecutor)getDriver();
		e.executeScript("arguments[0].value='" + value +"'", el);
	}
	
}
