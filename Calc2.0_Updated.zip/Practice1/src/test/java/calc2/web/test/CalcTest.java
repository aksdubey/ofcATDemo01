package calc2.web.test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.calc2.web.Calc2HomePO;

import Utilities.ConfigProvider;

public class CalcTest {
	List<String> str = new ArrayList<String>();
	
	String case1 = "2+3";
	String case2 = "10-2";
	String case3 = "(10-2)*2";
	String case4 = "sin(30)";
	
	public Calc2HomePO calc;
	
	@BeforeClass
	public void navigate() throws InterruptedException {
		calc= new Calc2HomePO("Chrome");
		calc.navigateToUrl(ConfigProvider.configFileReader("ApplicationUrl"));
		Thread.sleep(3000);
		Assert.assertEquals(calc.getDriver().getTitle(), "Web 2.0 scientific calculator","Page Title validated successfully");
		
	}
	
	@AfterMethod
	public void clear() throws InterruptedException {
		calc.clickOnClear();
		Thread.sleep(2000);
	}
	
	@Test(priority=0,description="Test Sum functionality")
	public void testSum() throws InterruptedException {
		
		calc.enterInput(case1);
		calc.clickEquals();
		Thread.sleep(2000);
		String result = calc.getResult();
		String ar[] = case1.split("\\+");
		int s = Integer.parseInt(ar[0])+Integer.parseInt(ar[1]);
		Assert.assertEquals(Integer.parseInt(result), s);
		str.add(case1+" = "+result);
	}
	
	@Test(priority=1,description="Test Substraction functionality")
	public void testSub() throws InterruptedException {
		calc.enterInput(case2);
		calc.clickEquals();
		Thread.sleep(2000);
		String result = calc.getResult();
		String ar[] = case2.split("-");
		int s = Integer.parseInt(ar[0])-Integer.parseInt(ar[1]);
		Assert.assertEquals(Integer.parseInt(result),s);
		str.add(case2+" = "+result);
	}
	
	@Test(priority=2,description="Test formula functionality")
	public void testformula() throws InterruptedException {
		calc.enterInput(case3);
		calc.clickEquals();
		Thread.sleep(3000);
		String result = calc.getResult();
		Assert.assertTrue(Integer.parseInt(result)!=18);
		str.add(case3+" = "+result);
	}
	
	@Test(priority=3,description="Test sine functionality")
	public void testSin() throws InterruptedException {
		calc.enterInput(case4);
		calc.clickEquals();
		Thread.sleep(2000);
		String result = calc.getResult();
		Assert.assertTrue(Double.parseDouble(result)==0.5);
		str.add(case4+" = "+result);
	}
	
	@Test(priority=4,description="Test sine functionality")
	public void verifyHistory() throws InterruptedException {
		calc.verifyHistory(str);;
		Thread.sleep(1000);
	}
	
	@AfterClass
	public void tearDown() {
		calc.getDriver().quit();
	}

}
