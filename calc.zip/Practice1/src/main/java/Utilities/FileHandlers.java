package Utilities;

import org.apache.commons.compress.archivers.dump.InvalidFormatException;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;

public class FileHandlers {

	// @Test
	public static void writeExcel(String path, String FileName, String Sheet, String rowkey,String Header,String value) throws org.apache.poi.openxml4j.exceptions.InvalidFormatException, FileNotFoundException {
		Workbook workbook;
		FileInputStream file = new FileInputStream(new File(path + "\\" + FileName));
		//Map<String, String> data = new HashMap<String, String>();
		try {
			if(FileName.contains(".xlsx"))
			{
				workbook=	new XSSFWorkbook(file);
			}else {
				workbook = WorkbookFactory.create(new File(path + "\\" + FileName));
			}
			DataFormatter dataFormatter = new DataFormatter();
			Sheet sheet = workbook.getSheet(Sheet);
			for (Row row : sheet) {
				if (!(row.getRowNum() == 0)) {
					if (dataFormatter.formatCellValue(row.getCell(0)).equalsIgnoreCase(rowkey))
						for (int i = 0; i < row.getLastCellNum(); i++) {
							if(sheet.getRow(0).getCell(i).getStringCellValue().equals(Header)){
								row.getCell(i).setCellValue(value);
							}
						}
				}
			}
			file.close();
			FileOutputStream outFile =new FileOutputStream(new File(path + "\\" + FileName));
			workbook.write(outFile);
			outFile.close();
			workbook.close();
			//return data;
		} catch (Exception e) {
			e.printStackTrace();
			//return data;
		} 
	}
	public static Map<String, String> readExcel(String path, String FileName, String Sheet, String rowkey) throws org.apache.poi.openxml4j.exceptions.InvalidFormatException, FileNotFoundException {
		Workbook workbook;
		FileInputStream file = new FileInputStream(new File(path + "\\" + FileName));
		Map<String, String> data = new HashMap<String, String>();
		try {
			if(FileName.contains(".xlsx"))
			{
				workbook=	new XSSFWorkbook(file);
			}else {
				workbook = WorkbookFactory.create(new File(path + "\\" + FileName));
			}
			DataFormatter dataFormatter = new DataFormatter();
			Sheet sheet = workbook.getSheet(Sheet);
			for (Row row : sheet) {
				if (!(row.getRowNum() == 0)) {
					if (dataFormatter.formatCellValue(row.getCell(0)).equalsIgnoreCase(rowkey))
						for (int i = 0; i < row.getLastCellNum(); i++) {
							data.put(dataFormatter.formatCellValue(sheet.getRow(0).getCell(i)),
									dataFormatter.formatCellValue(row.getCell(i)));
						}
				}
			}
			workbook.close();
			return data;
		} catch (Exception e) {
			e.printStackTrace();
			return data;
		} 
	}

	public static List<Map<String, String>> readExcelAllRow(String path, String FileName, String Sheet, String rowkey) throws org.apache.poi.openxml4j.exceptions.InvalidFormatException {
		Workbook workbook;
		
		Map<String, String> data;
		List<Map<String, String>> lst = new ArrayList<Map<String, String>>();
		try {
			if(FileName.contains(".xlsx"))
			{
				workbook=	new XSSFWorkbook(new FileInputStream(new File(path + "\\" + FileName)));
			}else {
				workbook = WorkbookFactory.create(new File(path + "\\" + FileName));
			}
			DataFormatter dataFormatter = new DataFormatter();
			Sheet sheet = workbook.getSheet(Sheet);
			for (Row row : sheet) {
				if (!(row.getRowNum() == 0)) {
					 data = new HashMap<String, String>();
						for (int i = 0; i < row.getLastCellNum(); i++) {
							data.put(dataFormatter.formatCellValue(sheet.getRow(0).getCell(i)),
									dataFormatter.formatCellValue(row.getCell(i)));
						}
							lst.add(data);
				}
			}
			workbook.close();
			return lst;
		} catch (Exception e) {
			e.printStackTrace();
			return lst;
		} 
	}
	
}