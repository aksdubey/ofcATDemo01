package Utilities;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class ScreenShot {
	public static void Screenshot(WebDriver driver) {
		File f = new File("d://worksoft/Screenhot_" +new Date().getDate()+ ".jpg");
		TakesScreenshot obj = (TakesScreenshot) driver;
		File file = obj.getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(file, f);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void Screenshot(WebDriver driver, String destPath) {
		File f = new File(destPath);
		if (driver != null && destPath.isEmpty()) {
			System.out.println("Path is null or empty");
			return;
		}
		TakesScreenshot obj = (TakesScreenshot) driver;
		File file = obj.getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(file, f);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void Screenshot(WebDriver driver, String destPath, String filename) {
		String path = destPath;
		path += "/" + filename + ".png";
		File f = new File(path);
		if (driver != null && destPath.isEmpty()) {
			System.out.println("Path is null or empty");
			return;
		}
		TakesScreenshot obj = (TakesScreenshot) driver;
		File file = obj.getScreenshotAs(OutputType.FILE);
		try {

			FileUtils.copyFile(file, f);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void Screenshot(WebDriver driver, String destPath, String filename, String FileExtension) {
		String path = destPath;

		if (FileExtension.isEmpty()) {
			System.out.println("Extension is null or Empty");
			return;
		} else if (FileExtension.matches("jpg;png;jpeg;JPG;PNG;JPEG")) {
			path += "/" + filename + "." + FileExtension;
		} else {
			path += "/" + filename + ".jpg";
		}
		if (driver != null && destPath.isEmpty()) {
			System.out.println("Path is null or empty");
			return;
		}

		if (driver != null && path.isEmpty()) {
			System.out.println("Path is null or empty");
			return;
		}
		File f = new File(path);
		TakesScreenshot obj = (TakesScreenshot) driver;
		File file = obj.getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(file, f);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}