package Utility;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FileHandlers {

	// @Test
	public static List<User> getuser(String path, String Sheet) {
		System.out.println("getUserClass");
		List<User> Listuser = new ArrayList<User>();
		User user;
		Workbook workbook;
		try {
			workbook = WorkbookFactory.create(new File(path));
			workbook = WorkbookFactory.create(new File(path));
			/*
			 * for (Sheet sheet : workbook) { // System.out.println("=> " +
			 * sheet.getSheetName()); }
			 */
			DataFormatter dataFormatter = new DataFormatter();
			Sheet sheet = workbook.getSheet(Sheet);
			// Sheet sheet = workbook.getSheetAt(0);
			for (Row row : sheet) {
				user = new User();
				Address ad = new Address();
				if (!(row.getRowNum() == 0)) {
					user.FirstName = dataFormatter.formatCellValue(row.getCell(0));
					user.LastName = dataFormatter.formatCellValue(row.getCell(1));
					user.UserName = dataFormatter.formatCellValue(row.getCell(2));
					user.Password = dataFormatter.formatCellValue(row.getCell(3));
					user.Email = dataFormatter.formatCellValue(row.getCell(4));
					user.HomePhone = dataFormatter.formatCellValue(row.getCell(5));
					user.MobilePhone = dataFormatter.formatCellValue(row.getCell(6));
					user.DateOfBirth = dataFormatter.formatCellValue(row.getCell(7));
					user.Company = dataFormatter.formatCellValue(row.getCell(8));
					user.Alias = dataFormatter.formatCellValue(row.getCell(9));
					ad.Address1 = dataFormatter.formatCellValue(row.getCell(10));
					ad.Address2 = dataFormatter.formatCellValue(row.getCell(11));
					ad.City = dataFormatter.formatCellValue(row.getCell(12));
					ad.State = dataFormatter.formatCellValue(row.getCell(13));
					ad.PinCode = dataFormatter.formatCellValue(row.getCell(14));
					ad.Country = dataFormatter.formatCellValue(row.getCell(15));
					user.Address = ad;
					System.out.print(user.FirstName + "\t");
					System.out.print(user.LastName + "\t");
					Listuser.add(user);
				}
				System.out.println();
			}
			workbook.close();
			return Listuser;
		} catch (EncryptedDocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return Listuser;
		} catch (InvalidFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return Listuser;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return Listuser;
		}
		// return user;
	}
}