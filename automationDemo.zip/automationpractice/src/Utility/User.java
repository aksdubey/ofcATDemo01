package Utility;

public class User {
	public String FirstName;
	public String LastName;
	public String UserName;
	public String Password;
	public String Email;
	public String HomePhone;
	public String MobilePhone;
	public String DateOfBirth;
	public String Company;
	public String Alias;
	public Address Address;

}
