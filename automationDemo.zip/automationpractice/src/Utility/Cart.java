package Utility;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class Cart {
	//@Test(groups = { "Search" }, priority = 4,dependsOnClass=)
	public static void add_cart(WebDriver wd, String name) throws InterruptedException {
		List<WebElement> add = wd.findElements(By.className("product-container"));
		Actions act = new Actions(wd);
		act.moveToElement(add.get(0)).build().perform();
		Thread.sleep(2000);
		wd.findElement(By.className("ajax_add_to_cart_button")).click();
		check_Out(wd);
	}

	//@Test(groups = { "Search" }, priority = 5)
	public static void check_Out(WebDriver wd) throws InterruptedException {
		Thread.sleep(2000);
		wd.findElement(By.xpath("//*[@title='Proceed to checkout']")).click();
		Thread.sleep(2000);
		WebElement item = wd.findElement(By.xpath("//span[@class='label label-success']"));
		Thread.sleep(2000);
		if (item.getText().equals("In stock")) {
			wd.findElement(By.className("standard-checkout")).click();
			wd.findElement(By.name("processAddress")).click();
			Thread.sleep(1000);
			wd.findElement(By.id("cgv")).click();
			Thread.sleep(2000);
			wd.findElement(By.className("standard-checkout")).click();
			// check_Out(wd);
		}

	}
}
