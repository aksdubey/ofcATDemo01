package Utility;

public class Address {
	public String Address1;
	public String Address2;
	public String City;
	public String State;
	public String PinCode;
	public String Country;
}
