package Utility;

import org.testng.annotations.Test;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(Listener.class)
public class Registration {
	public static WebDriver wd;
	User user;

	public User SetData() {
		User obj = new User();
		obj.FirstName = "Solanki";
		obj.LastName = "Patra";
		obj.DateOfBirth = "";
		obj.UserName = "solankipatra@gmail.com";
		obj.Password = "Solanki123@123";
		obj.Email = "solankipatra@gmail.com";
		obj.HomePhone = "779884894";
		obj.MobilePhone = "84516566";
		obj.Company = "CTS";
		obj.Alias = "SJKDHj";
		Address Adobj = new Address();
		Adobj.Address1 = "DHkj";
		Adobj.Address2 = "KJkl";
		Adobj.City = "Pune";
		Adobj.State = "Alabama";
		Adobj.PinCode = "35005";
		Adobj.Country = "United States";
		obj.Address = Adobj;
		return obj;
	}

	@BeforeTest(groups = { "SignInProcess", "CreateAccount", "ForgetPassword" })
	public void StartDriver() {
		System.setProperty("webdriver.chrome.driver", "d://worksoft/chromedriver.exe");
		wd = new ChromeDriver();
		wd.get("http://automationpractice.com/index.php");
		wd.manage().window().maximize();
		user = SetData();
	}

	@Test(groups = { "SignInProcess", "CreateAccount", "ForgetPassword" }, priority = 0)
	public void Bypass() {
		if (wd.getTitle().equalsIgnoreCase("Access to this site is blocked")) {
			wd.switchTo().frame("ws_blockoption");
			wd.findElement(By.id("wscontinue")).click();
			wd.switchTo().defaultContent();
		}
	}

	@Test(groups = { "SignInProcess", "CreateAccount", "ForgetPassword" }, priority = 1)
	public void SignIn_Click() {
		wd.findElement(By.xpath("//a[@title='Log in to your customer account']")).click();
	}

	@Test(groups = { "CreateAccount" }, priority = 2)
	public void Create_Account() throws InterruptedException {
		SignIn_Click();
		wd.findElement(By.xpath("//input[@id='email_create']")).sendKeys(user.Email);
		wd.findElement(By.id("SubmitCreate")).click();
		Thread.sleep(3000);
		List<WebElement> obj = wd.findElements(By.name("id_gender"));
		obj.get(0).click();
		wd.findElement(By.xpath("//input[@id='customer_firstname']")).sendKeys(user.FirstName);
		wd.findElement(By.xpath("//input[@id='customer_lastname']")).sendKeys(user.LastName);

		wd.findElement(By.xpath("//input[@id='passwd']")).sendKeys(user.Password);

		wd.findElement(By.xpath("//select[@id='days']")).sendKeys("24");

		wd.findElement(By.xpath("//select[@id='months']")).sendKeys("May");

		wd.findElement(By.xpath("//select[@id='years']")).sendKeys("2019");

		wd.findElement(By.xpath("//input[@id='newsletter']")).click();
		wd.findElement(By.xpath("//input[@id='optin']")).click();

		wd.findElement(By.xpath("//input[@id='company']")).sendKeys(user.Company);
		wd.findElement(By.xpath("//input[@id='address1']")).sendKeys(user.Address.Address1);
		wd.findElement(By.xpath("//input[@id='address2']")).sendKeys(user.Address.Address2);
		wd.findElement(By.xpath("//input[@id='city']")).sendKeys(user.Address.City);

		wd.findElement(By.xpath("//select[@id='id_state']")).sendKeys(user.Address.State);

		wd.findElement(By.xpath("//input[@id='postcode']")).sendKeys(user.Address.PinCode);

		wd.findElement(By.xpath("//select[@id='id_country']")).sendKeys(user.Address.Country);

		wd.findElement(By.xpath("//textarea[@id='other']")).sendKeys("other");
		wd.findElement(By.xpath("//input[@id='phone']")).sendKeys(user.HomePhone);
		wd.findElement(By.xpath("//input[@id='phone_mobile']")).sendKeys(user.MobilePhone);
		wd.findElement(By.xpath("//input[@id='alias']")).sendKeys(user.Alias);
		wd.findElement(By.id("submitAccount")).click();
		Thread.sleep(2000);
	}

	@Test(groups = { "SignInProcess", "Search" }, priority = 2)
	public void SignIn() {

		SignIn_Click();
		wd.findElement(By.xpath("//input[@id='email']")).sendKeys(user.Email);
		wd.findElement(By.xpath("//input[@id='passwd']")).sendKeys(user.Password);
		wd.findElement(By.xpath("//button[@id='SubmitLogin']//span")).click();

	}

	@Test(groups = { "ForgetPassword" }, priority = 2)
	public void Forget_Password() {
		SignIn_Click();
		wd.findElement(By.xpath("//a[contains(text(),'Forgot your password?')]")).click();
		try {
			Thread.sleep(2000);
			wd.findElement(By.xpath("//input[@id='email']")).sendKeys(user.Email);
			wd.findElement(By.xpath("//button[@type='submit']")).click();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
