package Utility;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(Listener.class)
public class Filter {

	@Test(groups = { "Search" }, priority = 3, dependsOnGroups = { "SignInProcess" })
	public void search_Item() {
		System.out.println(Registration.wd.getTitle());
		try {
			System.out.println("Search Started");
			Thread.sleep(2000);
			Registration.wd.findElement(By.id("search_query_top")).sendKeys("Tshirt");
			Registration.wd.findElement(By.name("submit_search")).click();

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@AfterTest(groups = { "SignInProcess", "CreateAccount", "ForgetPassword", "Search" })
	public void SignOut() {
		try {
			Thread.sleep(10000);
			if (Registration.wd.findElement(By.xpath("//a[contains(text(),'Sign out')]")).isDisplayed()) {
				Registration.wd.findElement(By.xpath("//a[contains(text(),'Sign out')]")).click();
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Registration.wd.close();
	}

	public void Select_Tab() {
		Registration.wd.findElement(By.xpath("//a[contains(@title='" + "Women" + "')]")).click();
	}

	/*
	 * public static void Select_Tab() { Actions act = new Actions();
	 * act.moveToElement(wd.findElement(By.id("search_query_top")));
	 * wd.findElement(By.name("submit_search")).click(); }
	 */

}
