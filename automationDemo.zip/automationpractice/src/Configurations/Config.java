package Configurations;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Config {
	public static WebDriver wd;

//@BeforeSuite
	public static void StartDriver() {
		System.setProperty("webdriver.chrome.driver", "d://worksoft/chromedriver.exe");
		wd = new ChromeDriver();
		wd.manage().window().maximize();

	}

	//@AfterSuite
	public static void CloseDriver() {
		System.out.println("Test closing");
		try {
			Thread.sleep(10000);
			Config.wd.close();
			Config.wd.quit();
			System.out.println("Test closed");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
