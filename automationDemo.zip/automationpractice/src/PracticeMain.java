

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class PracticeMain {
	WebDriver driver;

	PracticeMain() {
		System.setProperty("webdriver.chrome.driver", "d://worksoft/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://automationpractice.com/index.php");
		driver.manage().window().maximize();
	}

	public WebDriver getDriver() {
		return driver;
	}

	

	/*public static void main(String args[]) throws InterruptedException {

		Thread.sleep(2000);
		PracticeMain obj = new PracticeMain();
		Bypass(obj.getDriver());
		SignIn(obj.getDriver(),obj.SetData());
		Filter.search_Item(obj.getDriver(), "Faded Short Sleeve T-shirts");
		System.out.println("Item search");
		
		Cart.add_cart(obj.getDriver(), "Faded Short Sleeve T-shirts");
		System.out.println("Add cart");
		Thread.sleep(10000);
		//obj.getDriver().close();
		// Registration.SignIn(driver, PracticeMain.SetData());
	}*/
}
