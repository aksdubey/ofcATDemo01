package TestCases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import Configurations.Config;
import Handlers.Listener;

@Listeners(Handlers.Listener.class)
public class Filter {

	@Test(groups = { "Search" }, priority = 3, dependsOnGroups = { "SignInProcess" })
	public void search_Item() {
		System.out.println(Config.wd.getTitle());
		try {
			System.out.println("Search Started");
			Thread.sleep(2000);
			Config.wd.findElement(By.id("search_query_top")).sendKeys("Tshirt");
			Config.wd.findElement(By.name("submit_search")).click();

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void Select_Tab() {
		Config.wd.findElement(By.xpath("//a[contains(@title='" + "Women" + "')]")).click();
	}

}
