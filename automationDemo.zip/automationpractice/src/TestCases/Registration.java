package TestCases;

import org.testng.annotations.Test;
import Configurations.Config;
import Handlers.Listener;
import Utility.FileHandlers;
import Utility.User;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterGroups;
import org.testng.annotations.Listeners;

@Listeners(Listener.class)
public class Registration {
	User user = SetData();

	public User SetData() {
		User obj = new User();
		List<User> lstUser = FileHandlers.getuser("d://worksoft/Test.xlsx", "Sheet1");
		obj = lstUser.get(1);
		return obj;
	}

	@Test(groups = { "SignInProcess", "CreateAccount", "ForgetPassword" }, priority = 0)
	public void Bypass() {
		Config.wd.get("http://automationpractice.com/index.php");
		if (Config.wd.getTitle().equalsIgnoreCase("Access to this site is blocked")) {
			Config.wd.switchTo().frame("ws_blockoption");
			Config.wd.findElement(By.id("wscontinue")).click();
			Config.wd.switchTo().defaultContent();
		}
	}

	@Test(groups = { "SignInProcess", "CreateAccount", "ForgetPassword" }, priority = 1, dependsOnMethods = {
			"Bypass" })
	public void SignIn_Click() {
		Config.wd.findElement(By.xpath("//a[@title='Log in to your customer account']")).click();
	}

	@Test(groups = { "CreateAccount" }, priority = 2)
	public void Create_Account() throws InterruptedException {
		SignIn_Click();
		Config.wd.findElement(By.xpath("//input[@id='email_create']")).sendKeys(user.Email);
		Config.wd.findElement(By.id("SubmitCreate")).click();
		Thread.sleep(3000);
		List<WebElement> obj = Config.wd.findElements(By.name("id_gender"));
		obj.get(0).click();
		Config.wd.findElement(By.xpath("//input[@id='customer_firstname']")).sendKeys(user.FirstName);
		Config.wd.findElement(By.xpath("//input[@id='customer_lastname']")).sendKeys(user.LastName);

		Config.wd.findElement(By.xpath("//input[@id='passwd']")).sendKeys(user.Password);

		Config.wd.findElement(By.xpath("//select[@id='days']")).sendKeys("24");

		Config.wd.findElement(By.xpath("//select[@id='months']")).sendKeys("May");

		Config.wd.findElement(By.xpath("//select[@id='years']")).sendKeys("2019");

		Config.wd.findElement(By.xpath("//input[@id='newsletter']")).click();
		Config.wd.findElement(By.xpath("//input[@id='optin']")).click();

		Config.wd.findElement(By.xpath("//input[@id='company']")).sendKeys(user.Company);
		Config.wd.findElement(By.xpath("//input[@id='address1']")).sendKeys(user.Address.Address1);
		Config.wd.findElement(By.xpath("//input[@id='address2']")).sendKeys(user.Address.Address2);
		Config.wd.findElement(By.xpath("//input[@id='city']")).sendKeys(user.Address.City);

		Config.wd.findElement(By.xpath("//select[@id='id_state']")).sendKeys(user.Address.State);

		Config.wd.findElement(By.xpath("//input[@id='postcode']")).sendKeys(user.Address.PinCode);

		Config.wd.findElement(By.xpath("//select[@id='id_country']")).sendKeys(user.Address.Country);

		Config.wd.findElement(By.xpath("//textarea[@id='other']")).sendKeys("other");
		Config.wd.findElement(By.xpath("//input[@id='phone']")).sendKeys(user.HomePhone);
		Config.wd.findElement(By.xpath("//input[@id='phone_mobile']")).sendKeys(user.MobilePhone);
		Config.wd.findElement(By.xpath("//input[@id='alias']")).sendKeys(user.Alias);
		Config.wd.findElement(By.id("submitAccount")).click();
		Thread.sleep(2000);
	}

	@Test(groups = { "SignInProcess", "Search" }, priority = 2)
	public void SignIn() {

		SignIn_Click();
		Config.wd.findElement(By.xpath("//input[@id='email']")).sendKeys(user.Email);
		Config.wd.findElement(By.xpath("//input[@id='passwd']")).sendKeys(user.Password);
		Config.wd.findElement(By.xpath("//button[@id='SubmitLogin']//span")).click();
	}

	@Test(groups = { "ForgetPassword" }, priority = 2)
	public void Forget_Password() {
		SignIn_Click();
		Config.wd.findElement(By.xpath("//a[contains(text(),'Forgot your password?')]")).click();
		try {
			Thread.sleep(2000);
			Config.wd.findElement(By.xpath("//input[@id='email']")).sendKeys(user.Email);
			Config.wd.findElement(By.xpath("//button[@type='submit']")).click();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@AfterGroups(groups = { "SignInProcess", "CreateAccount", "ForgetPassword", "Search" })
	/* @AfterGroups(groups = {"*"}) */
	public void SignOut() {
		System.out.println("Signout");
		if (Config.wd.findElement(By.xpath("//a[contains(text(),'Sign out')]")).isDisplayed()) {
			Config.wd.findElement(By.xpath("//a[contains(text(),'Sign out')]")).click();
		}
	}
}
