package Demo.PageObject;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.formula.functions.Value;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import Utilities.CustomAnnotation;
import Utilities.FileHandlers;
import io.github.bonigarcia.wdm.DriverManagerType;
import io.github.bonigarcia.wdm.WebDriverManager;

/**
 * Hello world!
 *
 */
public class App 
{
   public static void main( String[] args ) throws IOException, InvalidFormatException
    {
		WebDriverManager.getInstance(DriverManagerType.CHROME).setup();
    	WebDriver driver=new ChromeDriver();
    	driver.navigate().to("https://www.google.com");
    	WebDriverWait wait = new WebDriverWait(driver, 30);
    	WebElement el = wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("q")));
    	el.sendKeys("Hello");
    	
    /*	String path =System.getProperty("user.dir")+"\\src";
    	System.out.println(path);
    	String File = "Demo.xlsx";
    	String File1 = "Demo.xlsx";
    	String Sheet ="input";
    	String rowkey="Abcd";
    	//System.out.println(FileHandlers.readExcel(path,File, Sheet, rowkey));	
    	FileHandlers.writeExcel(path,File, Sheet, rowkey,"Name","Akash");
    	System.out.println(FileHandlers.readExcelAllRow(path,File, Sheet, rowkey));	
    	//FileHandlers.read(path,File1);	
*/    }
}
