package Utilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ConfigProvider {

	public static String configFileReader(String sKey) {
		String sConfigFilePath = System.getProperty("user.dir") + "/src/selenium.properties";
		Properties prop = new Properties();
		InputStream input = null;
		String sValue = null;
		try {
			input = new FileInputStream(sConfigFilePath);
			prop.load(input);
			sValue = prop.getProperty(sKey);
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		 return sValue.trim(); 
	}
}