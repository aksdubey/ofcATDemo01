package tMobile.PO;

import org.openqa.selenium.By;

import Utilities.BasePageObject;

public class tMobileHomePo extends BasePageObject{
	public tMobileHomePo(){
		super();
	}
	
	public	tMobileHomePo(String BrowserName){
		super(BrowserName);
	}
	public enum FIELDS{
		
		PhoneLink(By.xpath("//a[contains(text(),'Phones')]")),
		FilterList(By.xpath("//button[@id='dropdownMenu1']")),
		NewConditionCheckBox(By.xpath("(//span[contains(text(),'New')])[1]")),
		AccessoriesLink(By.xpath("//span[contains(text(),'Accessories')]")),
		priceFilter(By.xpath("")),
		PriceHighToLowfilter(By.xpath("")),
		FirstproductName(By.xpath("(//browse-tile)[1]/div/a")),
		TMobileLogo(By.xpath("(//browse-tile)[1]/div/a"));
		private By findby;	
		FIELDS(By findby){
			this.findby = findby;
		}
	}
	
	public void navigateToPhone() {
		//driver.findElement(FIELDS.PhoneLink.findby);
		clickElementSafely(FIELDS.PhoneLink.findby);
	}
	
	public void Filter(String type) {
		clickElementSafely(FIELDS.FilterList.findby);
		if(type.contains("New")) {
			clickElementSafely(FIELDS.NewConditionCheckBox.findby);
		}
	}
	
	public void clickOnAccessories() {
		clickElementSafely(FIELDS.AccessoriesLink.findby);
	}
}
