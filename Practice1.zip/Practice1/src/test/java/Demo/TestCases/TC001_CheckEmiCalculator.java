package Demo.TestCases;

import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.*;

import Demo.PageObject.LoginPagePO;
import Utilities.ConfigProvider;

public class TC001_CheckEmiCalculator {

	public LoginPagePO login;
	@BeforeClass
	public void navigate() throws InterruptedException {
		login= new LoginPagePO("Chrome");
		
	}
	
	@Test
	public void TC001() throws InterruptedException {
		
		String Url = ConfigProvider.configFileReader("ApplicationUrl");
		System.out.println(Url);
		login.navigateToHomeUrl(Url);
		Thread.sleep(3000);
		Assert.assertEquals(login.getDriver().getTitle(), "Fixed Deposit Calculator - Calculate FD Interest Rates & Fixed Deposit Maturity - ICICI Bank","Page Title validated successfully");
		login.selectfdType("Quarterly");
		Thread.sleep(3000);
		
		login.enterloanAmount("60000");
		Thread.sleep(3000);
		
		login.getMaturityValue();
		login.getAggregateInterest();
		Thread.sleep(3000);
		
		login.selectDaysOnlyTenure();
		Thread.sleep(3000);
		
		login.enterDays("1000");
		Thread.sleep(3000);
		
		login.getMaturityValue();
		login.getAggregateInterest();
		Thread.sleep(3000);
		login.getDriver().switchTo().defaultContent();
		login.clickLogo();
		Thread.sleep(3000);
		//Assert.assertEquals(login.getDriver().getTitle(), "Personal Banking, Online Banking Services - ICICI Bank");
	}
	
	@AfterClass
	public void tearDown() {
		login.getDriver().quit();
	}
}
